"use strict";

const input = document.querySelector("input");
const add_btn = document.querySelector(".add_btn");
const menus = document.querySelector(".menus"); 

//메뉴 생성 함수 
let id = 0;
function createMenu(input_value){
    const menu = document.createElement('li');
    menu.setAttribute('class', 'menu');
    menu.setAttribute('data-id',id);
    menu.innerHTML = `
    <div class="menu_list">
        <span class="menu_name">${input_value}</span>
        <i class="fas fa-trash-alt" data-id=${id}></i>
    </div>
    <div class="menu_line"></div>
    `;

    id++;
    menus.appendChild(menu);
    menu.scrollIntoView({block:'center'});
}

//메뉴 추가 함수
function onAdd(){
    if(input.value == ''){
        return;
    }
    else{
        createMenu(input.value);
        input.value = null;
        input.focus();
    }
    
}

//1. 메뉴 추가 
// 1-1. enter 클릭
input.addEventListener('keypress', (event)=> {
    if( event.key=== "Enter"){
        onAdd();
    }
});

//1-2. +버튼 클릭
add_btn.addEventListener('click', ()=>{
    onAdd();
})


//2.삭제
menus.addEventListener('click', (event)=>{
    const id = event.target.dataset.id;
    if(id){
        const removeTraget = document.querySelector(`.menu[data-id="${id}"]`);
        removeTraget.remove();
    }
})





//

