"use strict";

const start_btn = document.querySelector(".start_btn");
const time_box = document.querySelector(".time_box");
const num_box = document.querySelector(".num_box");
const redo_box = document.querySelector(".redo_box");
const again_btn = document.querySelector(".again_btn");
const bug_img = document.querySelector(".bug_img");
const carrot_img = document.querySelector(".carrot_img");
const container_img = document.querySelector('.container_img');

//오디오
const audio_bg = new Audio('/carrot/sound/bg.mp3');
const audio_bg_pull = new Audio('/carrot/sound/bug_pull.mp3');
const audio_carrot_pull = new Audio('/carrot/sound/carrot_pull.mp3');
const audio_win = new Audio('/carrot/sound/game_win.mp3');


//난수 생성
function getRandomIntInclusive(min, max) {
  min = Math.ceil(min);
  max = Math.floor(max);
  return Math.floor(Math.random() * (max - min + 1)) + min; //최댓값도 포함, 최솟값도 포함
}

//시간 초과
function timeOut(){
    audio_bg.pause();
    audio_bg_pull.play();
    bug_imgs.forEach((bug)=>{
        bug.style.display = "none";
    })

    carrot_imgs.forEach((carrot)=>{
        carrot.style.display = "none";
    })
    start_btn.style.opacity = "0";
    start_btn.style.cursor = "default";
    redo_box.style.display = "block";
}

//성공
const redo_name = document.querySelector(".redo_name");
function success(){
    timeOut();
    audio_bg_pull.pause();
    audio_bg.pause();
    audio_win.play();
    redo_name.innerText = `Success!!!`;

}

//이미지 랜덤 배치
const bug_imgs = document.querySelectorAll('.bug_img');
const carrot_imgs = document.querySelectorAll('.carrot_img');

function showImg(){
    bug_imgs.forEach((bug)=>{
        bug.style.display = "block";
    })

    carrot_imgs.forEach((carrot)=>{
        carrot.style.display = "block";
    })
    //transition으로 보완하는게 좋을 듯.. 
    bug_imgs.forEach((bug)=>{
        const top = getRandomIntInclusive(0,210);
        const left = getRandomIntInclusive(0,800);
        bug.style.top = `${top}px`;
        bug.style.left = `${left}px`;
    })

    carrot_imgs.forEach((carrot)=>{
        const top = getRandomIntInclusive(0,180);
        const left = getRandomIntInclusive(0,800);
        carrot.style.top = `${top}px`;
        carrot.style.left = `${left}px`;
    })
    
}


//이미지 클릭
let carrot_click = 0;
function clickImg(timer){
    container_img.addEventListener('click', (event)=>{
        const datatype = event.target.dataset.type;
        if (datatype === 'carrot'){
            event.target.style.display = "none";  
            carrot_click++;   
            num--;

            audio_carrot_pull.play(); 
             // 문제) 버튼을 빠르게 클릭하면 소리가 안남. 

            num_box.innerText = `${num}`;
            if(num === 0){
                success();
                clearInterval(timer);
            }
        } else if (datatype === 'bug'){
            timeOut();
            clearInterval(timer);
            audio_bg_pull.play();
        } else{
            return; 
        }

    }) 
}


//1. 시작버튼 클릭 
let time = 10;
let num = 10;

function onClick(){
    start_btn.classList.add('started');
    //1.1정지 버튼으로 바꾸기
    start_btn.innerHTML = `
        <i class="fas fa-stop"></i>
    `;
    if (start_btn.classList.contains('started')){
        const stop_btn = document.querySelector('.start_btn.started');
        stop_btn.addEventListener('click',()=>{
            timeOut();
        })
    }
    
    //1.2 시간 10초 부여 & 1초씩 줄이기 
    time_box.innerHTML= `0 : ${time}`;
    const timer = setInterval(()=>{  
        time--;
        time_box.innerHTML= `0 : ${time}`;
        if (time === 0){
            clearInterval(timer);
            timeOut();
        }
    },1000);
    //1.3 숫자 10으로 바꾸기 
    num_box.innerText = `${num}`;

    clickImg(timer);
}


function startGame(){
    start_btn.addEventListener('click',()=>{
        audio_bg.play();
        onClick();
        showImg();
    })
    again_btn.addEventListener('click',()=>{
        console.log('restart');
        location.reload();
    })
}



startGame();